document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const authModal = document.getElementById('authModal');
    const appContainer = document.getElementById('appContainer');
    const loginTab = document.getElementById('loginTab');
    const signupTab = document.getElementById('signupTab');
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const closeBtn = document.querySelector('.close-btn');
    const loginBtn = document.querySelector('#login button');
    const signupBtn = document.querySelector('#signup button');
    const userBtn = document.getElementById('userBtn');
    const userDropdown = document.getElementById('userDropdown');
    const navBtns = document.querySelectorAll('.nav-btn');
    const contentSections = document.querySelectorAll('.content-section');
    const alertNotification = document.getElementById('alertNotification');
    const closeAlert = document.querySelector('.close-alert');
    const dismissAlertBtn = document.getElementById('dismissAlertBtn');
    const viewDetailsBtn = document.getElementById('viewDetailsBtn');
    const citySearch = document.getElementById('citySearch');
    const searchBtn = document.getElementById('searchBtn');
    const locateMeBtn = document.getElementById('locateMeBtn');
    const allergenFilter = document.getElementById('allergenFilter');
    const aqiTabs = document.querySelectorAll('.aqi-tab-btn');
    const aqiTabContents = document.querySelectorAll('.aqi-tab-content');
    const timelineViews = document.querySelectorAll('.view-btn');
    const timelineSections = document.querySelectorAll('.timeline-view');
    const prevMonthBtn = document.getElementById('prevMonthBtn');
    const nextMonthBtn = document.getElementById('nextMonthBtn');
    const currentMonthEl = document.getElementById('currentMonth');
    const calendarGrid = document.getElementById('calendarGrid');
    
    // Mock database for users
    const usersDB = [
        { email: 'user@example.com', password: 'password123', name: 'John Doe', age: 32, location: 'New York, NY', allergen: 'pollen', symptoms: ['sneezing', 'itchy_eyes'], alertPref: 'high' }
    ];
    
    // Current user variable
    let currentUser = null;
    
    // Initialize Google Maps
    let map;
    function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
            center: { lat: 28.5355, lng: 77.3910 }, // Noida coordinates
            zoom: 12
        });
        
        // Add some mock allergen markers
        addMockAllergenMarkers();
    }
    
    function addMockAllergenMarkers() {
        const allergens = [
            { lat: 28.5355, lng: 77.3910, type: 'pollen', level: 'high', title: 'High Pollen Area' },
            { lat: 28.5455, lng: 77.4010, type: 'dust', level: 'medium', title: 'Construction Dust' },
            { lat: 28.5255, lng: 77.3810, type: 'mold', level: 'low', title: 'Mold Spores Detected' },
            { lat: 28.5555, lng: 77.3710, type: 'pollen', level: 'high', title: 'Tree Pollen Hotspot' },
            { lat: 28.5155, lng: 77.4210, type: 'pet', level: 'medium', title: 'Pet Dander Area' }
        ];
        
        const levelColors = {
            high: '#FF6B6B',
            medium: '#FFD166',
            low: '#FFEE58',
            safe: '#4CAF50'
        };
        
        allergens.forEach(allergen => {
            new google.maps.Marker({
                position: { lat: allergen.lat, lng: allergen.lng },
                map: map,
                title: allergen.title,
                icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    fillColor: levelColors[allergen.level],
                    fillOpacity: 0.8,
                    strokeColor: '#fff',
                    strokeWeight: 1,
                    scale: 10
                }
            });
        });
    }
    
    // Initialize Charts
    function initCharts() {
        // Symptom Tracker Chart
        const symptomCtx = document.getElementById('symptomChart').getContext('2d');
        const symptomChart = new Chart(symptomCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Symptom Severity',
                    data: [3, 5, 7, 4, 8, 6],
                    borderColor: '#4A90E2',
                    backgroundColor: 'rgba(74, 144, 226, 0.1)',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 10
                    }
                }
            }
        });
        
        // AQI Forecast Chart
        const aqiCtx = document.getElementById('aqiChart').getContext('2d');
        const aqiChart = new Chart(aqiCtx, {
            type: 'bar',
            data: {
                labels: ['6AM', '9AM', '12PM', '3PM', '6PM', '9PM'],
                datasets: [{
                    label: 'AQI',
                    data: [85, 92, 104, 110, 95, 87],
                    backgroundColor: [
                        '#4CAF50',
                        '#FFD166',
                        '#FF6B6B',
                        '#9C27B0',
                        '#FFD166',
                        '#4CAF50'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // Initialize Calendar
    function initCalendar() {
        const now = new Date();
        updateCalendar(now.getFullYear(), now.getMonth());
    }
    
    function updateCalendar(year, month) {
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        currentMonthEl.textContent = `${monthNames[month]} ${year}`;
        
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        
        calendarGrid.innerHTML = '';
        
        // Add empty cells for days before the first day of the month
        for (let i = 0; i < firstDay; i++) {
            const emptyCell = document.createElement('div');
            emptyCell.className = 'calendar-day empty';
            calendarGrid.appendChild(emptyCell);
        }
        
        // Add cells for each day of the month
        for (let day = 1; day <= daysInMonth; day++) {
            const dayCell = document.createElement('div');
            dayCell.className = 'calendar-day';
            
            const dayNumber = document.createElement('div');
            dayNumber.className = 'day-number';
            dayNumber.textContent = day;
            dayCell.appendChild(dayNumber);
            
            // Add mock events (in a real app, these would come from a database)
            if (day % 5 === 0) {
                const event = document.createElement('div');
                event.className = 'day-event high';
                event.textContent = 'High Pollen';
                dayCell.appendChild(event);
            } else if (day % 3 === 0) {
                const event = document.createElement('div');
                event.className = 'day-event medium';
                event.textContent = 'Dust Alert';
                dayCell.appendChild(event);
            } else if (day % 7 === 0) {
                const event = document.createElement('div');
                event.className = 'day-event low';
                event.textContent = 'Mold Warning';
                dayCell.appendChild(event);
            }
            
            calendarGrid.appendChild(dayCell);
        }
    }
    
    // Event Listeners
    loginTab.addEventListener('click', () => {
        loginTab.classList.add('active');
        signupTab.classList.remove('active');
        loginForm.classList.add('active');
        signupForm.classList.remove('active');
    });
    
    signupTab.addEventListener('click', () => {
        signupTab.classList.add('active');
        loginTab.classList.remove('active');
        signupForm.classList.add('active');
        loginForm.classList.remove('active');
    });
    
    closeBtn.addEventListener('click', () => {
        authModal.style.display = 'none';
    });
    
    loginBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        
        // Simple validation
        if (!email || !password) {
            alert('Please fill in all fields');
            return;
        }
        
        // Check user credentials
        const user = usersDB.find(u => u.email === email && u.password === password);
        
        if (user) {
            currentUser = user;
            authModal.style.display = 'none';
            appContainer.classList.remove('hidden');
            showAlertNotification();
            initMap();
            initCharts();
            initCalendar();
            updateUserProfile();
        } else {
            alert('Invalid email or password');
        }
    });
    
    signupBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const name = document.getElementById('signupName').value;
        const age = document.getElementById('signupAge').value;
        const location = document.getElementById('signupLocation').value;
        const allergen = document.getElementById('signupAllergen').value;
        const symptoms = Array.from(document.querySelectorAll('input[name="symptoms"]:checked')).map(cb => cb.value);
        const alertPref = document.querySelector('input[name="alertPref"]:checked').value;
        const policyChecked = document.querySelector('#signup input[type="checkbox"]').checked;
        
        // Simple validation
        if (!name || !age || !location || !allergen || symptoms.length === 0 || !alertPref || !policyChecked) {
            alert('Please fill in all required fields and agree to the policy');
            return;
        }
        
        // Create new user (in a real app, this would be saved to a database)
        const email = `${name.toLowerCase().replace(/\s/g, '')}@example.com`;
        const password = 'password123';
        
        const newUser = {
            email,
            password,
            name,
            age,
            location,
            allergen,
            symptoms,
            alertPref
        };
        
        usersDB.push(newUser);
        currentUser = newUser;
        
        authModal.style.display = 'none';
        appContainer.classList.remove('hidden');
        showAlertNotification();
        initMap();
        initCharts();
        initCalendar();
        updateUserProfile();
        
        alert('Account created successfully! Use email: ' + email + ' and password: password123 for future logins.');
    });
    
    userBtn.addEventListener('click', () => {
        userDropdown.style.display = userDropdown.style.display === 'block' ? 'none' : 'block';
    });
    
    window.addEventListener('click', (e) => {
        if (!e.target.matches('#userBtn')) {
            if (userDropdown.style.display === 'block') {
                userDropdown.style.display = 'none';
            }
        }
    });
    
    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.getAttribute('data-target');
            
            navBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            contentSections.forEach(section => {
                section.classList.remove('active');
                if (section.id === `${target}Section`) {
                    section.classList.add('active');
                }
            });
        });
    });
    
    closeAlert.addEventListener('click', () => {
        alertNotification.classList.add('hidden');
    });
    
    dismissAlertBtn.addEventListener('click', () => {
        alertNotification.classList.add('hidden');
    });
    
    viewDetailsBtn.addEventListener('click', () => {
        alertNotification.classList.add('hidden');
        // Navigate to Maps section
        navBtns.forEach(b => b.classList.remove('active'));
        document.querySelector('.nav-btn[data-target="maps"]').classList.add('active');
        
        contentSections.forEach(section => {
            section.classList.remove('active');
            if (section.id === 'mapsSection') {
                section.classList.add('active');
            }
        });
    });
    
    searchBtn.addEventListener('click', () => {
        const searchTerm = citySearch.value.trim();
        if (searchTerm) {
            // In a real app, this would search for the location and update the map
            alert(`Searching for: ${searchTerm}`);
        }
    });
    
    locateMeBtn.addEventListener('click', () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                position => {
                    const pos = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    
                    map.setCenter(pos);
                    // In a real app, you might add a marker or update allergen data
                    alert(`Location found: ${pos.lat}, ${pos.lng}`);
                },
                () => {
                    alert('Unable to retrieve your location. Using default location.');
                    map.setCenter({ lat: 28.5355, lng: 77.3910 });
                }
            );
        } else {
            alert('Geolocation is not supported by your browser. Using default location.');
            map.setCenter({ lat: 28.5355, lng: 77.3910 });
        }
    });
    
    allergenFilter.addEventListener('change', () => {
        const selectedAllergen = allergenFilter.value;
        // In a real app, this would filter the map markers
        alert(`Filtering by: ${selectedAllergen}`);
    });
    
    aqiTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const tabId = tab.getAttribute('data-tab');
            
            aqiTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            aqiTabContents.forEach(content => {
                content.classList.remove('active');
                if (content.id === `${tabId}Tab`) {
                    content.classList.add('active');
                }
            });
        });
    });
    
    timelineViews.forEach(view => {
        view.addEventListener('click', () => {
            const viewType = view.getAttribute('data-view');
            
            timelineViews.forEach(v => v.classList.remove('active'));
            view.classList.add('active');
            
            timelineSections.forEach(section => {
                section.classList.remove('active');
                if (section.id === `${viewType}View`) {
                    section.classList.add('active');
                }
            });
        });
    });
    
    prevMonthBtn.addEventListener('click', () => {
        const currentDate = new Date(currentMonthEl.textContent + ' 1');
        currentDate.setMonth(currentDate.getMonth() - 1);
        updateCalendar(currentDate.getFullYear(), currentDate.getMonth());
    });
    
    nextMonthBtn.addEventListener('click', () => {
        const currentDate = new Date(currentMonthEl.textContent + ' 1');
        currentDate.setMonth(currentDate.getMonth() + 1);
        updateCalendar(currentDate.getFullYear(), currentDate.getMonth());
    });
    
    // Helper Functions
    function showAlertNotification() {
        if (currentUser && currentUser.alertPref !== 'none') {
            setTimeout(() => {
                alertNotification.classList.remove('hidden');
            }, 2000);
        }
    }
    
    function updateUserProfile() {
        if (currentUser) {
            document.getElementById('userProfileName').textContent = currentUser.name;
            document.getElementById('userLocation').textContent = currentUser.location;
            document.getElementById('userAge').textContent = `Age: ${currentUser.age}`;
            document.getElementById('primaryAllergen').textContent = currentUser.allergen.charAt(0).toUpperCase() + currentUser.allergen.slice(1);
            
            const symptomsList = document.getElementById('symptomsList');
            symptomsList.innerHTML = '';
            currentUser.symptoms.forEach(symptom => {
                const li = document.createElement('li');
                li.textContent = symptom.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
                symptomsList.appendChild(li);
            });
        }
    }
    
    // Initialize the app
    authModal.style.display = 'flex';
});